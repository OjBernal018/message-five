from email import message
import sqlite3

def val_user(user, password):
    db=sqlite3.connect("db/mensajes.s3db")
    db.row_factory=sqlite3.Row
    cursor = db.cursor()
    query ="select *from usuarios where correo='"+user+"' and  password='"+password+"' and estado='1'"
    cursor.execute(query)
    result = cursor.fetchall()
    return result


def list_addressee(user):
    db=sqlite3.connect("db/mensajes.s3db")
    db.row_factory=sqlite3.Row
    cursor = db.cursor()
    query ="select *from usuarios where correo<>'"+user+"'"
    cursor.execute(query)
    result = cursor.fetchall()
    return result


def reg_email(origin, destiny, subject, message):
    db=sqlite3.connect("db/mensajes.s3db")
    db.row_factory=sqlite3.Row
    cursor = db.cursor()
    query ="insert into mensajeria (asunto,mensaje,fecha,hora,id_usu_envia,id_usu_recibe,estado) values ('"+subject+"','"+message+"',DATE('now'),TIME('NOW'),'"+origin+"','"+destiny+"','0')"
    cursor.execute(query)
    db.commit()
    return "1"


def reg_user(name,email, password, code):
    db=sqlite3.connect("db/mensajes.s3db")
    db.row_factory=sqlite3.Row
    cursor = db.cursor()
    query ="insert into usuarios(nombres,correo,password,estado,codigoactivacion) values ('"+name+"','"+email+"','"+password+"','0','"+code+"')"
    cursor.execute(query)
    db.commit()
    return "1"

def act_user(code):
    db=sqlite3.connect("db/mensajes.s3db")
    db.row_factory=sqlite3.Row
    cursor = db.cursor()
    query ="update usuarios set estado='1' where codigoactivacion='"+code+"'"
    cursor.execute(query)
    db.commit()

    queryTwo ="select *from usuarios where codigoactivacion='"+code+"' and estado='1'"
    cursor.execute(queryTwo)
    result = cursor.fetchall()
    return result
