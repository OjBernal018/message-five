from email import message
import sqlite3


def send_view(email):
    db = sqlite3.connect("db/mensajes.s3db")
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
    query = "select m.asunto,m.mensaje,m.fecha,m.hora, u.nombres from usuarios u, mensajeria m where u.correo=m.id_usu_recibe and m.id_usu_envia='"+email+"' order by fecha desc "
    cursor.execute(query)
    result = cursor.fetchall()
    return result


def send_capture(email):
    db = sqlite3.connect("db/mensajes.s3db")
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
    query = "select m.asunto,m.mensaje,m.fecha,m.hora, u.nombres from usuarios u, mensajeria m where u.correo=m.id_usu_envia and m.id_usu_recibe='"+email+"' order by fecha desc "
    cursor.execute(query)
    result = cursor.fetchall()
    return result


def val_user(user, password):
    db = sqlite3.connect("db/mensajes.s3db")
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
    query = "select *from usuarios where correo='"+user + \
        "' and  password='"+password+"' and estado='1'"
    cursor.execute(query)
    result = cursor.fetchall()
    return result


def list_addressee(user):
    db = sqlite3.connect("db/mensajes.s3db")
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
    query = "select *from usuarios where correo<>'"+user+"'"
    cursor.execute(query)
    result = cursor.fetchall()
    return result


def update_pass(password, correo):
    db = sqlite3.connect("db/mensajes.s3db")
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
    query = "update usuarios set password='"+password+"' where correo='"+correo+"'"
    cursor.execute(query)
    db.commit()
    return "1"


def reg_email(origin, destiny, subject, message):
    db = sqlite3.connect("db/mensajes.s3db")
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
    query = "insert into mensajeria (asunto,mensaje,fecha,hora,id_usu_envia,id_usu_recibe,estado) values ('" + \
        subject+"','"+message + \
            "',DATE('now'),TIME('NOW'),'"+origin+"','"+destiny+"','0')"
    cursor.execute(query)
    db.commit()
    return "1"


def reg_user(name, email, password, code):
    try:
        db = sqlite3.connect("db/mensajes.s3db")
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
        query = "insert into usuarios(nombres,correo,password,estado,codigoactivacion) values ('"+ \
            name+"','"+email+"','"+password+"','0','"+code+"')"
        cursor.execute(query)
        db.commit()

        return "USUARIO REGISTRADO SATISFACTORIAMENTE"
    except:
        return "ERROR!!!...No se pudo registrar el usuario. El CORREO y/o NOMBRE DE USUARIO ya existen."


def act_user(code):
    db = sqlite3.connect("db/mensajes.s3db")
    db.row_factory = sqlite3.Row
    cursor = db.cursor()
    query = "update usuarios set estado='1' where codigoactivacion='"+code+"'"
    cursor.execute(query)
    db.commit()

    queryTwo = "select *from usuarios where codigoactivacion='"+code+"' and estado='1'"
    cursor.execute(queryTwo)
    result = cursor.fetchall()
    return result
