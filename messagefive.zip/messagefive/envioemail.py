import smtplib 
from email.message import EmailMessage 

def enviar(destinationEmail, message, subject):
    try:
        email_origen="fernandezem@uninorte.edu.co"
        password="mariusconsolelog7"
        email = EmailMessage()
        email["From"] = email_origen
        email["To"] = destinationEmail
        email["Subject"] = subject
        email.set_content(message)

        # Send Email
        smtp = smtplib.SMTP("smtp-mail.outlook.com", port=587)
        smtp.starttls()
        smtp.login(email_origen, password)
        smtp.sendmail(email_origen, destinationEmail, email.as_string())
        smtp.quit()
        return "1"
    except:
        return "0"