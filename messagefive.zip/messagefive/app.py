
from flask import Flask, render_template, request
import hashlib
import controlador
from datetime import datetime
import envioemail

app = Flask(__name__)

email_origin = ""


@app.route("/")
def initial():
    return render_template("login.html")


@app.route("/valUsers", methods=["GET", "POST"])
def valUsers():
    if request.method == "POST":
        user = request.form["txtusuario"]
        user = user.replace("SELECT", "").replace("INSERT", "").replace(
            "DELETE", "").replace("UPDATE", "").replace("WHERE", "")
        passw = request.form["txtpass"]
        passw = passw.replace("SELECT", "").replace("INSERT", "").replace(
            "DELETE", "").replace("UPDATE", "").replace("WHERE", "")

        passHash = passw.encode()
        passHash = hashlib.sha384(passHash).hexdigest()

        response = controlador.val_user(user, passHash)

        global email_origin

        if len(response) == 0:
            email_origin = ""
            message = "¡ERROR DE AUTENTICACIÓN! Verifique su nombre de usuario (correo electrónico) o contraseña"
            return render_template("informacion.html", data=message)
        else:
            email_origin = user
            responseTow = controlador.list_addressee(user)

            return render_template("principal.html", data=responseTow, infoUser=response)


@app.route("/regUsers", methods=["GET", "POST"])
def regUsers():
    if request.method == "POST":
        name = request.form["txtnombre"]
        name = name.replace("SELECT", "").replace("INSERT", "").replace(
            "DELETE", "").replace("UPDATE", "").replace("WHERE", "")
        email = request.form["txtusuarioregistro"]
        email = email.replace("SELECT", "").replace("INSERT", "").replace(
            "DELETE", "").replace("UPDATE", "").replace("WHERE", "")
        passw = request.form["txtpassregistro"]
        passw = passw.replace("SELECT", "").replace("INSERT", "").replace(
            "DELETE", "").replace("UPDATE", "").replace("WHERE", "")

        passHash = passw.encode()
        passHash = hashlib.sha384(passHash).hexdigest()

        code = datetime.now()
        codeAct = str(code)
        codeAct = codeAct.replace("-", "")
        codeAct = codeAct.replace(" ", "")
        codeAct = codeAct.replace(":", "")
        codeAct = codeAct.replace(".", "")

        response = controlador.reg_user(name, email, passHash, codeAct)
        if response == "1":
            message = "Sr, " + name+" su codigo de activacion es :\n\n"+codeAct + \
                "\n\n Recuerde copiarlo y pegarlo para validarlo en la seccion de login y activar su cuenta.\n\nMuchas Gracias"
            subject = "Código de Activación"
            responseEmail = envioemail.enviar(email, message, subject)
            if responseEmail == 1:
                message = "Usuario Registrado Satisfactoriamente"
            else:
                message = "Registrado correctamente, Email no enviado, lo invitamos a utilizar el sigiente código de activación: "+codeAct
        else:
            message = "ERROR, el usuario y/o correo ya existen, verifique sus datos y vuelva a intentarlo"
            return render_template("informacion.html", data=response)


@app.route("/sendMessage", methods=["GET", "POST"])
def sendMessage():
    if request.method == "POST":
        subject = request.form["subject"]

        subject = subject.replace("SELECT", "").replace("INSERT", "").replace("DELETE", "").replace("UPDATE", "").replace("WHERE", "")

        message = request.form["message"]

        message = message.replace("SELECT", "").replace("INSERT", "").replace("DELETE", "").replace("UPDATE", "").replace("WHERE", "")

        destinationEmail = request.form["destinationEmail"]

        destinationEmail = destinationEmail.replace("SELECT", "").replace("INSERT", "").replace("DELETE", "").replace("UPDATE", "").replace("WHERE", "")

        controlador.reg_email(email_origin, destinationEmail, subject, message)

        messageTwo = "Sr: Usuario, tiene un mensaje nuevo, ingrese a la plataforma y, en la pestaña historial puede leerlo. \n\n ¡¡Muchas gracias!!"

        envioemail.enviar(destinationEmail, messageTwo, "Nuevo mensaje entregado...")

        return "¡¡Email entregado satisfactoriamente!!"


@app.route("/historySend", methods=["GET", "POST"])
def historySend():
    result = controlador.send_view(email_origin)

    return render_template("response.html", data=result)


@app.route("/historyCapture", methods=["GET", "POST"])
def historyCapture():
    result = controlador.send_capture(email_origin)

    return render_template("response2.html", data=result)


@app.route("/passwordUpdate", methods=["GET", "POST"])
def passwordUpdate():
    if request.method == "POST":
        passOne = request.form["pass"]
        passOne = passOne.replace("SELECT", "").replace("INSERT", "").replace(
            "DELETE", "").replace("UPDATE", "").replace("WHERE", "")
        passHash = passOne.encode()
        passHash = hashlib.sha384(passHash).hexdigest()

        response = controlador.update_pass(passHash, email_origin)

        return "Actualización de Password Satifactorio"


@app.route("/activUsers", methods=["GET", "POST"])
def activUsers():
    if request.method == "POST":
        actCode = request.form["txtcodigo"]
        actCode = actCode.replace("SELECT", "").replace("INSERT", "").replace(
            "DELETE", "").replace("UPDATE", "").replace("WHERE", "")

        response = controlador.act_user(actCode)

    if len(response) == 0:
        message = "EL CÓDIGO DE ACTIVACIÓN ES INCORRECTO, COMPRUÉBALO."

    else:
        message = "EL USUARIO HA SIDO ACTIVADO CON ÉXITO."

    return render_template("informacion.html", data=message)
