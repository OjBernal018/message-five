
import email
from flask import Flask, render_template, request
import hashlib
import controlador
from datetime import datetime
import envioemail

app = Flask(__name__)

email_origin = ""


@app.route("/")
def initial():
    return render_template("login.html")


@app.route("/valUsers", methods = ["GET", "POST"])
def valUsers():
    if request.method == "POST":
        user = request.form["txtusuario"]
        passw = request.form["txtpass"]

        passHash = passw.encode()
        passHash = hashlib.sha384(passHash).hexdigest()

        response = controlador.val_user(user, passHash)

        global email_origin

        if len(response) == 0:
            email_origin = ""
            message = "¡ERROR DE AUTENTICACIÓN! Verifique su nombre de usuario (correo electrónico) o contraseña"
            return render_template("informacion.html", data = message)
        else:
            email_origin = user
            responseTow = controlador.list_addressee(user)
            print("USUARIO: " + user)
            print("PASSWORD: " + passw)
            print("PASSWORD ENCRIPTADO: " + passHash)

            return render_template("principal.html", data = responseTow, infoUser=response)


@app.route("/regUsers", methods=["GET", "POST"])
def regUsers():
    if request.method == "POST":
        name = request.form["txtnombre"]
        email = request.form["txtusuarioregistro"]
        passw = request.form["txtpassregistro"]

        passHash = passw.encode()
        passHash = hashlib.sha384(passHash).hexdigest()

        code = datetime.now()
        codeAct = str(code)
        codeAct = codeAct.replace("-", "")
        codeAct = codeAct.replace(" ", "")
        codeAct = codeAct.replace(":", "")
        codeAct = codeAct.replace(".", "")

        print(codeAct)

        controlador.reg_user(name, email, passHash, codeAct)

        message = "Sr, " + name + " su codigo de activacion es :\n\n"+codeAct+ "\n\n Recuerde copiarlo y pegarlo para validarlo en la seccion de login y activar su cuenta.\n\nMuchas Gracias"
        
        envioemail.enviar(email, message,"Código de Activación")


        message = "HOLA USUARIO " +name+" TU REGISTRO ES SATISFACTORIO."
        return render_template("informacion.html", data = message)


@app.route("/sendMessage", methods = ["GET", "POST"])
def sendMessage():
    if request.method == "POST":
        subject = request.form["subject"]
        message = request.form["message"]
        destinationEmail = request.form["destinationEmail"]

        controlador.reg_email(email_origin, destinationEmail, subject, message)

        messageTwo = "Sr: Usuario, tiene un mensaje nuevo, ingrese a la plataforma y, en la pestaña historial puede leerlo. \n\n ¡¡Muchas gracias!!"
        
        envioemail.enviar(destinationEmail, messageTwo,"NUEVO MENSAJE ENTREGADO...")

        return "¡¡EMAIL ENTREGADO SACTIFACTORIAMENTE!!"


@app.route("/activUsers", methods=["GET", "POST"])
def activUsers():
    if request.method == "POST":
        actCode = request.form["txtcodigo"]

        response = controlador.act_user(actCode)

        if len(response) == 0:
            message = "EL CÓDIGO DE ACTIVACIÓN ES INCORRECTO, COMPRUÉBALO."

        else:
            message = "EL USUARIO HA SIDO ACTIVADO CON ÉXITO."

        return render_template("informacion.html", data = message)
